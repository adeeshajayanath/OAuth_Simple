I made some changes to google API files to avoid some irritating errors.

If you want to live with those errors... you can remove // to active those codes ;) 


in vendor\google\apiclient\src\Google\Client.php
line number 469 - 472

    //$expired = ($created
      //+ ($this->token['expires_in'] - 30)) < time();

    //return $expired;

    remove comments
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

in in vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php on line 67 to line 80


    if (count($this->handles) >= $this->maxHandles) {
        //     curl_close($resource);
        // } else {
        //     // Remove all callback functions as they can hold onto references
        //     // and are not cleaned up by curl_reset. Using curl_setopt_array
        //     // does not work for some reason, so removing each one
        //     // individually.
        //     curl_setopt($resource, CURLOPT_HEADERFUNCTION, null);
        //     curl_setopt($resource, CURLOPT_READFUNCTION, null);
        //     curl_setopt($resource, CURLOPT_WRITEFUNCTION, null);
        //     curl_setopt($resource, CURLOPT_PROGRESSFUNCTION, null);
        //     curl_reset($resource);
        //     $this->handles[] = $resource;
        // }

          remove comments